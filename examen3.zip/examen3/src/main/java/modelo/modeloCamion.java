/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author mateo
 */
public class modeloCamion extends modeloVehiculo {
    
    String capacidadCarga;

    public modeloCamion(String capacidadCarga, String marca, String modelo) {
        super(marca, modelo);
        this.capacidadCarga = capacidadCarga;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(String capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public String toString() {
        return "Camion{" +"Marca: "+getMarca()+"\n"+"Modelo: "+getModelo()+"\n"+ "Capacidad de Carga: " + capacidadCarga + '}';
    }
    
    
    
    
}
