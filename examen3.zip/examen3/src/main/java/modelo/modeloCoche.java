
package modelo;


public class modeloCoche extends modeloVehiculo{
    
    String esElectrico;

    public modeloCoche(String esElectrico, String marca, String modelo) {
        super(marca, modelo);
        this.esElectrico = esElectrico;
    }

    public String getEsElectrico() {
        return esElectrico;
    }

    public void setEsElectrico(String esElectrico) {
        this.esElectrico = esElectrico;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    
    
    
    
    @Override
    public String toString() {
        return "Coche{" +"Marca: "+getMarca()+"\n"+"Modelo: "+getModelo()+"\n"+ "Electrico: " + esElectrico + '}';
    }
    
    
    
}
