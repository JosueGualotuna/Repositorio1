
package controlador;

import java.util.ArrayList;
import modelo.modeloCamion;
import modelo.modeloCoche;
import modelo.modeloVehiculo;


public class gestorFlota {
  
    
 public ArrayList<modeloVehiculo> listaVehiculo; 
    
    private static gestorFlota instancia;

    public gestorFlota() {
        this.listaVehiculo = new ArrayList<>();
    }
    
     public static gestorFlota getInstancia(){
        if(instancia==null){
            instancia=new gestorFlota();
        }
        return instancia;
    }
    

     public modeloVehiculo agregarVehiculo(String marca, String modelo){
         modeloVehiculo vehiculo = new modeloVehiculo(marca, modelo);
     listaVehiculo.add(vehiculo);
         return vehiculo;
     }
     
          public modeloVehiculo agregarCoche(String esElectrico,String marca, String modelo){
              modeloCoche vehiculo = new modeloCoche(esElectrico, marca, modelo);
     listaVehiculo.add(vehiculo);
         return vehiculo;
     }
     
            public modeloVehiculo agregarCamion(String capacidadCarga,String marca, String modelo){
                modeloCamion vehiculo = new modeloCamion(capacidadCarga, marca, modelo);
     listaVehiculo.add(vehiculo);
         return vehiculo;
     }
 
     
         public ArrayList<modeloVehiculo> listadoCompleto(){
        return listaVehiculo;
    }       
            
            
         public void imprimirlista (){
             
             for(modeloVehiculo ve : listaVehiculo){
                 System.out.println(ve+"\n");
             }
             
             
         }
         
         
}
