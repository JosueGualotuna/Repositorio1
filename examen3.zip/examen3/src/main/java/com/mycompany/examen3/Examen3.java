

package com.mycompany.examen3;

import controlador.gestorFlota;
import java.util.Scanner;
import modelo.modeloCoche;
import modelo.modeloVehiculo;
import vista.vistaIngresoSalida;


public class Examen3 {

    public static void main(String[] args) {


        gestorFlota  gf= gestorFlota.getInstancia();
        modeloVehiculo v1 = gf.agregarVehiculo("toyota", "modelo 2020");
        modeloVehiculo v2 = gf.agregarVehiculo("chevrolet", "modelo 2010");
        modeloVehiculo v3 = gf.agregarVehiculo("chevrolet", "modelo 2005");

        modeloVehiculo coche1 =gf.agregarCoche("es electrico", "tesla", "modelo 2000");
        modeloVehiculo coche2 =gf.agregarCoche("no es electrico", "chevrolet", "modelo 2007");
        modeloVehiculo coche3 =gf.agregarCoche("es electrico", "toyota", "modelo 2011");

        modeloVehiculo camion1 = gf.agregarCamion("Carga maxima", "toyota ", " modelo 2015");
                modeloVehiculo camion2 = gf.agregarCamion("Carga minima", "tesla ", " modelo 2011");
                modeloVehiculo camion3 = gf.agregarCamion("Carga media", "BMW ", " modelo 2017");

          Scanner entrada = new Scanner(System.in);
    vista.vistaIngresoSalida vistag = new vistaIngresoSalida();
int opcion = 0;
do{
    System.out.println("                ===FLOTA DE CARROS===");
    System.out.println("1) Agregar vehiculo");
        System.out.println("2) Agregar coche");
        System.out.println("3) Agregar camion");
                System.out.println("4) Mostrar flota ");

                System.out.println("5) Salir");

    System.out.print("ENTRADA: ");
    opcion= entrada.nextInt();
   entrada.nextLine();
                     System.out.println("");

   switch(opcion){
       
       case 1: 
                                String marca = vistag.agregarMarcaVehiculo();
          String modelo= vistag.agregarModeloVehiculo();
gf.agregarVehiculo(marca, modelo);
                  System.out.println("VEHICULO AGREGADO EXITOSAMENTE");
                  System.out.println("");

           break;
           
              case 2: 
            String marca1 = vistag.agregarMarcaCoche();
          String modelo1= vistag.agregarModeloCoche();
                    String electrico = vistag.agregarElectrico();

gf.agregarCoche(electrico, marca1, modelo1);
                  System.out.println("COCHE AGREGADO EXITOSAMENTE");
                  System.out.println("");
           break;
           
              case 3: 
              String marca3 = vistag.agregarMarcaCamion();
          String modelo3= vistag.agregarModeloCamion();
                    String carga = vistag.agregarCarga();

gf.agregarCamion(carga, marca3, modelo3);
                             System.out.println("CAMION AGREGADO EXITOSAMENTE");
                  System.out.println("");

           break;
           
              case 4:
                  System.out.println("          ===LISTA DE LA FLOTA===");
                gf.imprimirlista();    
  
                  break;
           
   }
   
   
}
while(opcion!=5);


    
    }
}
