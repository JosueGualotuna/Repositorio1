
package vista;

import java.util.Scanner;


public class vistaIngresoSalida {
  
    Scanner entrada = new Scanner(System.in);
    String nombre = "";
        String marca = "";
        String electrico = "";
        String carga = "";

 public String agregarModeloVehiculo(){
             System.out.print("Ingrese el modelo del vehiculo: ");
nombre = entrada.nextLine();
return nombre;
 }   
    
  public String agregarMarcaVehiculo(){
             System.out.print("Ingrese la marca del vehiculo: ");
marca = entrada.nextLine();
return marca;
 }   
 
   public String agregarModeloCoche(){
             System.out.print("Ingrese el modelo del coche: ");
nombre = entrada.nextLine();
return nombre;
 }   
    
  public String agregarMarcaCoche(){
             System.out.print("Ingrese la marca del coche: ");
marca = entrada.nextLine();
return marca;
 }   

   public String agregarModeloCamion(){
             System.out.print("Ingrese el modelo del camion: ");
nombre = entrada.nextLine();
return nombre;
 }   
    
  public String agregarMarcaCamion(){
             System.out.print("Ingrese la marca del camion: ");
marca = entrada.nextLine();
return marca;
 }   

  
  
   public String agregarElectrico(){
             System.out.print("Ingrese Electrico / No electrico del coche: ");
electrico = entrada.nextLine();
return electrico;
 }   

      public String agregarCarga(){
             System.out.print("Ingrese la capacidad de carga del camion:  ");
carga = entrada.nextLine();
return carga;
 }    
}
