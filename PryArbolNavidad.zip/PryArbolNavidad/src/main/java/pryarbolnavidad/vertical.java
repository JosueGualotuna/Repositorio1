
package pryarbolnavidad;

public class vertical {
    
    
    public void metVertical(int m,int n){
   String matriz [][]=new String [m][n];
int mitad = matriz[0].length/2;
for(int i= (m/2);i<matriz.length;i++){
   for(int j=0;j<matriz[0].length;j++){
    if((i+j)==mitad+i  ){
        matriz[i][j]="*"; 
         } 
        else{
                matriz[i][j]=" ";
                }
       System.out.print(matriz[i][j]+" ");
}
    System.out.println();
} 
}
}

