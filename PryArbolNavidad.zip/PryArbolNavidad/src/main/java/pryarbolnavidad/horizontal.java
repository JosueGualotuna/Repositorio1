package pryarbolnavidad;

public class horizontal {
    public void metHorizontal(int m, int n) {
        String matriz[][] = new String[m][n];
        int mitad = n / 2; 
        int rango = n / 4; 

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                matriz[i][j] = " ";
            }
        }

        for (int i = 0; i < matriz.length / 2; i++) { 
            for (int j = mitad - rango; j <= mitad + rango; j++) { 
                if (j >= 0 && j < matriz[0].length) { 
                    matriz[i][j] = "*";
                }
            }
        }

        for (int i = 0; i < matriz.length / 2; i++) { 
            for (int j = 0; j < matriz[0].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }
}
