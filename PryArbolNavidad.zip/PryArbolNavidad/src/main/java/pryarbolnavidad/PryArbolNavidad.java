
package pryarbolnavidad;
import java.util.Scanner;

public class PryArbolNavidad {

    public static void main(String[] args) {
Scanner entrada = new Scanner(System.in);
        System.out.println("            ARBOL DE NAVIDAD\n");
        System.out.println("RANGO DE LA MATRIZ [i][j]");
        System.out.println("Se recomienda lo siguiente: ");
        System.out.println("- #columnas >= doble de #filas");
        System.out.println();
                System.out.print("Ingrese el numero de filas (i): ");
int m=entrada.nextInt();
        System.out.print("Ingrese el numero de columnas (j): ");
int n=entrada.nextInt();

triangulo arriba = new triangulo();
arriba.metArriba(m, n);

vertical medio = new vertical();
medio.metVertical(m, n);

horizontal abajo = new horizontal();
abajo.metHorizontal(m,n);
}

}

