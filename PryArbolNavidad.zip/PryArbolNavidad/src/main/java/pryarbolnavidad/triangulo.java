
package pryarbolnavidad;

public class triangulo {
    
    
    public void metArriba(int m,int n){
   String matriz [][]=new String [m][n];
int mitad = matriz[0].length/2;
for(int i=0;i<matriz.length;i++){
   for(int j=0;j<matriz[0].length;j++){
    if((i+j)>=mitad &&(j-i)<=mitad){
        matriz[i][j]="*"; 
         } 
        else{
                matriz[i][j]=" ";
                }
       System.out.print(matriz[i][j]+" ");
}
    System.out.println();
} 
}
}
