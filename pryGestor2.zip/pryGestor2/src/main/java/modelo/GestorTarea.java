/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author mateo
 */
public class GestorTarea {
    private ArrayList<Tarea> listaTareas;

    public GestorTarea() {
        listaTareas = new ArrayList<>();
    }

    public void agregarTarea(Tarea tarea) {
        listaTareas.add(tarea);
    }

    public ArrayList<Tarea> obtenerTareas() {
        return listaTareas;
    }
    
       public Tarea obtenerTareaPorId(int id) {
        for (Tarea tarea : listaTareas) {
            if (tarea.getId() == id) {
                return tarea;
            }
        }
        return null;
    }

    public boolean eliminarTarea(int id) {
        Tarea tarea = obtenerTareaPorId(id);
        if (tarea != null) {
            listaTareas.remove(tarea);
            return true;
        }
        return false;
    }
    
}
