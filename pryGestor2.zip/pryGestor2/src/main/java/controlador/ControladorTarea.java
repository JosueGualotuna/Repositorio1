/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import modelo.GestorTarea;
import modelo.Tarea;
import vista.VistaPrincipal;

public class ControladorTarea {
     private GestorTarea gestor;
    private VistaPrincipal vista;

    public ControladorTarea(GestorTarea gestor, VistaPrincipal vista) {
        this.gestor = gestor;
        this.vista = vista;

        this.vista.Guardar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarTarea();
                           
            }
        });
      this.vista.Actualizar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarTarea();
            }
        });   
        
       this.vista.Eliminar(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarTarea();
            }
        });    
    }

    
    
    
    private void guardarTarea() {
                
if(vista.getIdTarea().isEmpty()||vista.getNombreIngresado().isEmpty()||vista.getDescripcionTarea().isEmpty()||vista.getEstadoTarea().isEmpty()){
    JOptionPane.showMessageDialog(vista, "DEBE LLENAR TODOS LOS DATOS");
    
}else{
        int id = Integer.parseInt(vista.getIdTarea());
        String nombre = vista.getNombreIngresado();
                    String descripcion = vista.getDescripcionTarea();
            String estado = vista.getEstadoTarea();
            Tarea tarea = new Tarea(id, nombre, descripcion, estado);
            gestor.agregarTarea(tarea);
            vista.mostrarTareas(gestor.obtenerTareas());

            vista.limpiarCampoTexto();
            
    }   }
    
    
     private void actualizarTarea() {
        try {
            int id = Integer.parseInt(vista.getIdTarea());
            String nombre = vista.getNombreIngresado();
            String descripcion = vista.getDescripcionTarea();
            String estado = vista.getEstadoTarea();

            Tarea tareaExistente = gestor.obtenerTareaPorId(id);
            if (tareaExistente != null) {
                tareaExistente.setNombre(nombre);
                tareaExistente.setDescripcion(descripcion);
                tareaExistente.setEstado(estado);
                tareaExistente.setId(id);

                vista.mostrarTareas(gestor.obtenerTareas());

vista.limpiarCampoTexto();
            } else {
                JOptionPane.showMessageDialog(vista, "NO EXISTE UNA TAREA CON ESE ID");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "INGRESE EL ID CORRECTAMENTE");
        }
        }  
     
         private void eliminarTarea() {
        try {
            int id = Integer.parseInt(vista.getIdTarea());

            boolean eliminado = gestor.eliminarTarea(id);
            if (eliminado) {

                vista.mostrarTareas(gestor.obtenerTareas());

         vista.limpiarCampoTexto();
            } else {
                JOptionPane.showMessageDialog(vista, "NO EXISTE UNA TAREA CON ESE ID");
            }
        } catch (NumberFormatException numero) {
            JOptionPane.showMessageDialog(vista, "INGRESE EL ID CORRECTAMENTE");
 
        }
    }
        
        
        
    }
    
    

