

package com.mycompany.prygestor2;

import controlador.ControladorTarea;
import javax.swing.SwingUtilities;
import modelo.GestorTarea;
import vista.VistaPrincipal;


public class PryGestor2 {

    public static void main(String[] args) {
  
       GestorTarea gestor = new GestorTarea();
            VistaPrincipal vista = new VistaPrincipal();
     ControladorTarea controlador = new ControladorTarea(gestor, vista);
            vista.setVisible(true);
    
    }
}
